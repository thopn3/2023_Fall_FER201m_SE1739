import './App.css';

function App() {
  return (
    <h1>PE</h1>
  );
}

export default App;
